// src/components/Message.js
import React from 'react';
import './Message.css';

export default function Message({ role, content }) {
  return (
    <div className={`message ${role}`}>
      <strong>{role === 'user' ? 'You' : 'Bot'}:</strong> {content}
    </div>
  );
}
