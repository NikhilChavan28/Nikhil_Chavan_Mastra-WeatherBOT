// src/components/ChatHistory.js
import React from 'react';
import './ChatHistory.css';

export default function ChatHistory({ historyList, onSelect }) {
  return (
    <div className="chat-history">
      <h3>ChatGPT History</h3>
      <ul>
        {historyList.map(threadId => (
          <li key={threadId} onClick={() => onSelect(threadId)}>
            {threadId}
          </li>
        ))}
      </ul>
    </div>
  );
}
