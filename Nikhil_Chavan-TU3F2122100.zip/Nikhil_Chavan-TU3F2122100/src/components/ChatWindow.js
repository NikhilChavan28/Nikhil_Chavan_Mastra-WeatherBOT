// src/components/ChatWindow.js
import React, { useState, useRef, useEffect } from 'react';
import Message from './Message';
import ChatHistory from './ChatHistory';
import './ChatWindow.css';

const API_URL = "https://brief-thousands-sunset-9fcb1c78-485f-4967-ac04-2759a8fa1462.mastra.cloud/api/agents/weatherAgent/stream";
const DEFAULT_THREAD_ID = "TU3F2122100"; // You can replace this with unique user IDs if needed

export default function ChatWindow() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [threadId, setThreadId] = useState(DEFAULT_THREAD_ID);
  const [historyList, setHistoryList] = useState([]);
  const bottomRef = useRef(null);

  const STORAGE_KEY = `chat_history_${threadId}`;

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      setMessages(JSON.parse(saved));
    } else {
      setMessages([]);
    }
  }, [threadId]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(messages));

    // Update the thread list
    const keys = Object.keys(localStorage)
      .filter(k => k.startsWith('chat_history_'))
      .map(k => k.replace('chat_history_', ''));
    setHistoryList(keys);
  }, [messages]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMsg = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Accept': '*/*',
          'Content-Type': 'application/json',
          'xx-mastra-dev-playground': 'true',
          'Authorization': `Bearer ${process.env.REACT_APP_API_KEY}`
        },
        body: JSON.stringify({
          messages: [userMsg],
          runId: "weatherAgent",
          maxRetries: 2,
          maxSteps: 5,
          temperature: 0.5,
          topP: 1,
          runtimeContext: {},
          threadId: threadId,
          resourceId: "weatherAgent"
        })
      });

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let resultText = '';
      let buffer = '';

      // Add initial blank agent message
      setMessages(prev => [...prev, { role: 'agent', content: '' }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop();

        lines.forEach(line => {
          line = line.trim();
          if (line.startsWith('0:')) {
            const content = line.slice(2).trim().replace(/^"|"$/g, '');
            resultText += content;

            // Update the last message
            setMessages(prev => {
              const updated = [...prev];
              updated[updated.length - 1] = { role: 'agent', content: resultText };
              return updated;
            });
          }
        });
      }

    } catch (err) {
      console.error('❌ Stream error:', err);
      setMessages(prev => [...prev, { role: 'agent', content: '❌ Error fetching data' }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !loading) sendMessage();
  };

  const clearChat = () => {
    localStorage.removeItem(STORAGE_KEY);
    setMessages([]);
  };

  const handleHistorySelect = (id) => {
    setThreadId(id);
  };

  return (
    <div className="chat-layout">
      <ChatHistory historyList={historyList} onSelect={handleHistorySelect} />
      <div className="chat-container">
        <div className="messages">
          {messages.map((msg, i) => (
            <Message key={i} role={msg.role} content={msg.content} />
          ))}
          <div ref={bottomRef} />
        </div>
        <div className="input-area">
          <input
            type="text"
            placeholder="Type a message..."
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            disabled={loading}
          />
          <button onClick={sendMessage} disabled={loading}>
            {loading ? '...' : 'Send'}
          </button>
          <button onClick={clearChat} className="clear-button">
            Clear Chat
          </button>
        </div>
      </div>
    </div>
  );
}
